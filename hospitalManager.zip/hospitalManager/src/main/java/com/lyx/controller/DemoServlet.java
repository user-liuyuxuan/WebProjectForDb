package com.lyx.controller;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/DemoServlet")
public class DemoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //创建session对象
        HttpSession session = request.getSession();
        //设置一个付款金额
        String pay = request.getParameter("chargenum");
        Double price = Double.valueOf(pay);
        System.out.println("price = " + price);
        //将此付款金额存到session域中
        session.setAttribute("price",price);
        //转发到index界面
        String contextPath = request.getContextPath();
        response.sendRedirect(contextPath+"/zfb/index.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
