package com.lyx.controller.appointment;

import com.lyx.service.AnnouncementService;
import com.lyx.service.impl.AnnouncementServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/announcement/addAnnouncement")
public class AddAnnouncementServlet extends HttpServlet {
    private AnnouncementService announcementService = new AnnouncementServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求中的参数
        String announcementTitle = req.getParameter("announcementTitle");
        String announcementContent = req.getParameter("announcementContent");
        String adminName = req.getParameter("adminName");
        System.out.println("adminName = " + adminName);

        boolean flag =  announcementService.addAnnouncement(announcementTitle, announcementContent, adminName);
        if(flag){
            resp.sendRedirect(req.getContextPath()+"/announcement/getAnnouncementList");
        }

    }
}
