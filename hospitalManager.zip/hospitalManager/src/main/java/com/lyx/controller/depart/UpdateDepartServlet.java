package com.lyx.controller.depart;

import com.lyx.pojo.Departments;
import com.lyx.service.DepartService;
import com.lyx.service.impl.DepartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/depart/updateDepart")
public class UpdateDepartServlet extends HttpServlet {
    private DepartService departService = new DepartServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String departname = req.getParameter("departname");
        String departdesc = req.getParameter("departdesc");
        String id = req.getParameter("id");
        Departments departments = new Departments();
        departments.setDepartmentName(departname);
        departments.setDepartmentDescription(departdesc);
        if(id!=null && !"".equals(id)){
            departments.setDepartmentId(Integer.parseInt(id));
        }
        boolean flag = departService.updateDepartment(departments);
        if(flag){
            resp.sendRedirect(req.getContextPath()+"/depart/getDepartList");
        }
    }
}
