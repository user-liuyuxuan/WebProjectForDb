package com.lyx.controller.announcement;

import com.lyx.pojo.Announcement;
import com.lyx.service.AnnouncementService;
import com.lyx.service.impl.AnnouncementServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


//用于多条件获取医生信息
@WebServlet("/announcement/getToUpdateAnnouncementData")
public class GetToUpdateAnnouncementDataServlet extends HttpServlet {
    private AnnouncementService announcementService = new AnnouncementServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String anId = req.getParameter("anId");
        //调用业务层查询方法,需要分页用PageInfo

        Announcement announcement = announcementService.getToUpdateAnnouncementData(anId);
        //跳转jsp页面，显示数据，把需要展示数据设置到request作用域中
        req.setAttribute("announcement",announcement);
        System.out.println("announcement = " + announcement);
        //使用转发的跳转方式
        req.getRequestDispatcher("/updateAnnouncement.jsp").forward(req,resp);




    }
}
