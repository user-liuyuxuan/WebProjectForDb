package com.lyx.controller.appointment;


import com.lyx.pojo.Appointments;
import com.lyx.service.AppointmentService;
import com.lyx.service.ScheduleService;
import com.lyx.service.impl.AppointmentServiceImpl;
import com.lyx.service.impl.ScheduleServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/appointment/deleteAppointmentByAid")
public class DeleteAppointmentServlet extends HttpServlet {
    private AppointmentService appointmentService = new AppointmentServiceImpl();
    private ScheduleService scheduleService = new ScheduleServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String aid = req.getParameter("aid");
        String pid = req.getParameter("pid");
        String date = req.getParameter("date");
        String time = req.getParameter("time");
        String did = req.getParameter("did");
        boolean flag1 = appointmentService.deleteAppointmentByAid(aid);
        boolean flag2 = scheduleService.updateDoctorScheduleByDoctorIdAndDateAndShiftTime(date,time,did);
        if(flag1 && flag2){
            resp.sendRedirect(req.getContextPath()+"/appointment/getAppointmentListByPid?pid="+pid);
        }
    }
}
