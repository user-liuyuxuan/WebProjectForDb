package com.lyx.controller.patient;

import com.lyx.service.PatientService;
import com.lyx.service.impl.PatientServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/patient/deletePatientsById")
public class DeletePatientsServlet extends HttpServlet {
    private PatientService  patientsService = new PatientServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求中的参数
        String id = req.getParameter("id");

        boolean flag = patientsService.deletePatientsById(Integer.valueOf(id));
        if(flag){
            resp.sendRedirect(req.getContextPath()+"/patient/getPatientsList");
        }

    }
}
