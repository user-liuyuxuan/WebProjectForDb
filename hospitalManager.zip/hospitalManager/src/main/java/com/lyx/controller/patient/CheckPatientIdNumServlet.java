package com.lyx.controller.patient;

import com.lyx.pojo.Patients;
import com.lyx.service.PatientService;
import com.lyx.service.impl.PatientServiceImpl;
import com.lyx.util.FileUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/patient/checkIdNum")
@MultipartConfig
public class CheckPatientIdNumServlet extends HttpServlet {
    private PatientService patientService = new PatientServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idnum = req.getParameter("idnum");
        boolean flag = patientService.checkIdNum(idnum);
        PrintWriter writer = resp.getWriter();
        writer.print(flag);
        writer.flush();
        writer.close();
    }
}
