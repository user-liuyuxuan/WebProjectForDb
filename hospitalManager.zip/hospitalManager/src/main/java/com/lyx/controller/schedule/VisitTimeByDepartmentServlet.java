package com.lyx.controller.schedule;

import com.lyx.pojo.DoctorSchedule;
import com.lyx.service.ScheduleService;
import com.lyx.service.impl.ScheduleServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/schedule/visitTimeByDepartment")
public class VisitTimeByDepartmentServlet extends HttpServlet {
    private ScheduleService scheduleService = new ScheduleServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String did = req.getParameter("did");
        List<DoctorSchedule> doctorScheduleList = scheduleService.getDoctorScheduleList(did);
        req.setAttribute("doctorScheduleList", doctorScheduleList);
        req.getRequestDispatcher("/Front/visitsTime.jsp").forward(req, resp);
    }
}
