package com.lyx.controller;

import com.lyx.pojo.Admins;
import com.lyx.pojo.Doctors;
import com.lyx.service.AdminService;
import com.lyx.service.DoctorService;
import com.lyx.service.impl.AdminServiceImpl;
import com.lyx.service.impl.DoctorServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/user/logout")
public class LogoutServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String r=req.getParameter("r");
        if("1".equals(r)){
            req.getSession().removeAttribute("admins");
            resp.sendRedirect(req.getContextPath()+"/login.jsp");
        }
        else if("2".equals(r)){
            req.getSession().removeAttribute("doctors");
            resp.sendRedirect(req.getContextPath()+"/login.jsp");
        }
        else if("3".equals(r)){
            req.getSession().removeAttribute("patientlogin");
            req.getSession().removeAttribute("patients");
            resp.sendRedirect(req.getContextPath()+"/Front/index.jsp");
        }
    }
}
