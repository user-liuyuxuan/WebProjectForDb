package com.lyx.controller.announcement;

import com.lyx.service.AnnouncementService;
import com.lyx.service.impl.AnnouncementServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/announcement/deleteAnnouncementById")
public class DeleteAnnouncementByIdServlet extends HttpServlet {
    private AnnouncementService announcementService = new AnnouncementServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求中的参数
        String id = req.getParameter("id");
        boolean flag = announcementService.deleteAnnouncementById(id);
        if(flag){
            resp.sendRedirect(req.getContextPath()+"/announcement/getAnnouncementList");
        }



    }
}
