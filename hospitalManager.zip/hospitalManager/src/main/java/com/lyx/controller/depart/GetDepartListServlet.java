package com.lyx.controller.depart;

import com.github.pagehelper.PageInfo;
import com.lyx.service.DepartService;
import com.lyx.service.impl.DepartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/depart/getDepartList")
public class GetDepartListServlet extends HttpServlet {
    private DepartService departService = new DepartServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String page = req.getParameter("page");
        PageInfo pageInfo = departService.getDepartListPage(page, 0);
        req.setAttribute("pageInfo", pageInfo);
        req.getRequestDispatcher("/departList.jsp").forward(req, resp);
    }
}
