package com.lyx.controller.announcement;

import com.lyx.pojo.Announcement;
import com.lyx.service.AnnouncementService;
import com.lyx.service.impl.AnnouncementServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/announcement/updateAnnouncementData")
@MultipartConfig
public class UpdateAnnouncementDataServlet extends HttpServlet {
    private AnnouncementService announcementService = new AnnouncementServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求中的参数
        String announcementId = req.getParameter("announcementId");
        String title = req.getParameter("title");
        String creator = req.getParameter("creator");
        String creationTime = req.getParameter("creationTime");
        String content = req.getParameter("content");

        //封装announcement
        Announcement announcement = new Announcement(Integer.valueOf(announcementId),title,  content,  creationTime,  creator);

        boolean flag = announcementService.updateAnnouncementData(announcement);

        if(flag){
            //替换session中得信息，重新查询医生信息，放到session中
            resp.sendRedirect(req.getContextPath() + "/announcement/getAnnouncementList");
        }


    }
}
