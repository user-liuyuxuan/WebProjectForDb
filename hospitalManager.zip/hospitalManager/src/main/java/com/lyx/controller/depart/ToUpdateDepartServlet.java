package com.lyx.controller.depart;

import com.lyx.pojo.Departments;
import com.lyx.service.DepartService;
import com.lyx.service.impl.DepartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/depart/toUpdate")
public class ToUpdateDepartServlet extends HttpServlet {
    private DepartService departService = new DepartServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String did = req.getParameter("did");
        Departments departments = departService.getDepartById(did);
        req.setAttribute("departments", departments);
        req.getRequestDispatcher("/updateDepart.jsp").forward(req, resp);
    }
}
