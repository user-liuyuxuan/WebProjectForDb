package com.lyx.controller.patient;

import com.lyx.pojo.Patients;
import com.lyx.service.PatientService;
import com.lyx.service.impl.PatientServiceImpl;
import com.lyx.util.FileUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;

@WebServlet("/patient/signin")
@MultipartConfig
public class SigninPatientServlet extends HttpServlet {
    private PatientService patientService = new PatientServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idnum = req.getParameter("idnum");
        String pwd = req.getParameter("pwd");
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");
        Patients patients = new Patients(idnum,pwd,name,phone,email);
        Part part = req.getPart("myfile");
        if (part != null && part.getSize() > 0) {
            String myfile = FileUtil.transferTo(req, "myfile");
            patients.setAvatar(myfile);
        }
        boolean flag = patientService.patientSignin(patients);
        if(flag){
            resp.sendRedirect(req.getContextPath()+"/Front/patientLogin.jsp");
        }
    }
}
