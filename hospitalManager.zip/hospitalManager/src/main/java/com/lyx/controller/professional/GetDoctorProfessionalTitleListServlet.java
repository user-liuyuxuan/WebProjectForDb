package com.lyx.controller.professional;

import com.github.pagehelper.PageInfo;
import com.lyx.service.ProfessionalTitlesService;
import com.lyx.service.impl.ProfessionalTitlesServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


//用于多条件获取医生信息
@WebServlet("/doctor/getDoctorProfessionalTitledList")
public class GetDoctorProfessionalTitleListServlet extends HttpServlet {
    private ProfessionalTitlesService pofessionalTitlesService = new ProfessionalTitlesServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求中的参数
        String page = req.getParameter("page");
        String ptId = req.getParameter("ptId");
        //创建对象封装查询参数
        //调用业务层查询方法,需要分页用PageInfo
        PageInfo pageInfo = pofessionalTitlesService.getDoctorProfessionalTitlesListPage(page);
        //跳转jsp页面，显示数据，把需要展示数据设置到request作用域中
        req.setAttribute("pageInfo",pageInfo);
        //使用转发的跳转方式
        req.getRequestDispatcher("/professionalTitles.jsp").forward(req,resp);




    }
}
