package com.lyx.controller.schedule;

import com.lyx.pojo.Appointments;
import com.lyx.pojo.DoctorSchedule;
import com.lyx.service.AppointmentService;
import com.lyx.service.PatientService;
import com.lyx.service.ScheduleService;
import com.lyx.service.impl.AppointmentServiceImpl;
import com.lyx.service.impl.PatientServiceImpl;
import com.lyx.service.impl.ScheduleServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/schedule/booked")
public class BookedServlet extends HttpServlet {
    private ScheduleService scheduleService = new ScheduleServiceImpl();
    private AppointmentService appointmentService = new AppointmentServiceImpl();
    private PatientService patientService = new PatientServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String sid = req.getParameter("sid");
        System.out.println("sid = " + sid);
        String pid = req.getParameter("pid");
        System.out.println("pid = " + pid);
        String restfee = req.getParameter("restfee");
        boolean flag1 = scheduleService.updateDoctorScheduleById(sid);
        DoctorSchedule doctorSchedule = scheduleService.getDoctorScheduleById(sid);
        boolean flag2 = appointmentService.addAppointment(doctorSchedule,pid);
        boolean flag3 = patientService.updatePatientBalanceById(pid,restfee);
        if (flag1 && flag2 && flag3) {
            resp.sendRedirect(req.getContextPath()+ "/appointment/getAppointmentListByPid?pid="+pid);
        }
    }
}
