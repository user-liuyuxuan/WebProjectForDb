package com.lyx.controller.doctor;

import com.lyx.pojo.Departments;
import com.lyx.pojo.Doctors;
import com.lyx.service.DepartService;
import com.lyx.service.DoctorService;
import com.lyx.service.impl.DepartServiceImpl;
import com.lyx.service.impl.DoctorServiceImpl;
import com.lyx.util.FileUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;

@WebServlet("/doctor/updateDoctor")
@MultipartConfig
public class UpdateDoctorServlet extends HttpServlet {
    private DoctorService doctorService = new DoctorServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String jobNumber = req.getParameter("jobNumber");
        String name = req.getParameter("name");
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");
        String registrationFee = req.getParameter("registrationFee");
        String introduction = req.getParameter("introduction");
        String pid = req.getParameter("pid");
        String entryDate = req.getParameter("entryDate");
        String avatar = req.getParameter("avatar");
        Doctors doctors = new Doctors(jobNumber,name,phone,email,introduction,registrationFee,entryDate,Integer.valueOf(pid));
        doctors.setAvatar(avatar);
        Part part = req.getPart("myfile");
        if (part != null && part.getSize() > 0) {
            String myfile = FileUtil.transferTo(req, "myfile");
            doctors.setAvatar(myfile);
        }
        boolean flag = doctorService.updateDoctorByJobNumber(doctors);
        if(flag){
            resp.sendRedirect(req.getContextPath()+"/doctorIndex.jsp");
        }
    }
}
