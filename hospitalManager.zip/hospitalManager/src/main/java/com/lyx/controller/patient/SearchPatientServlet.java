package com.lyx.controller.patient;

import com.github.pagehelper.PageInfo;
import com.lyx.service.PatientService;
import com.lyx.service.impl.PatientServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/patient/searchPatients")
public class SearchPatientServlet extends HttpServlet {
    private PatientService patientsService = new PatientServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String page = req.getParameter("page");
        String patientName = req.getParameter("patientName");
        String patientIdCardNumber = req.getParameter("patientIdCardNumber");
        //调用业务层查询方法,需要分页用PageInfo
        PageInfo pageInfo = patientsService.searchPatientsList(patientName,patientIdCardNumber,page);
        //跳转jsp页面，显示数据，把需要展示数据设置到request作用域中
        req.setAttribute("pageInfo", pageInfo);

        //使用转发的跳转方式
        req.getRequestDispatcher("/patientsList.jsp").forward(req, resp);
    }
}
