package com.lyx.controller.appointment;


import com.lyx.pojo.Appointments;
import com.lyx.service.AppointmentService;
import com.lyx.service.impl.AppointmentServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/appointment/getAppointmentListByPid")
public class GetAppointmentListByPidServlet extends HttpServlet {
    private AppointmentService appointmentService = new AppointmentServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pid = req.getParameter("pid");
        List<Appointments> appointmentsList = appointmentService.getAppointmentListByPid(pid);
        req.setAttribute("appointmentsList", appointmentsList);
        req.getRequestDispatcher("/Front/bookedInfo.jsp").forward(req, resp);
    }
}
