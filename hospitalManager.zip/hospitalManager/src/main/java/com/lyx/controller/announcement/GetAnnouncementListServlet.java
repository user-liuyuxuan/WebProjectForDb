package com.lyx.controller.announcement;

import com.github.pagehelper.PageInfo;
import com.lyx.pojo.Announcement;
import com.lyx.service.AnnouncementService;
import com.lyx.service.impl.AnnouncementServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


//用于多条件获取医生信息
@WebServlet("/announcement/getAnnouncementList")
public class GetAnnouncementListServlet extends HttpServlet {
    private AnnouncementService announcementService = new AnnouncementServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String sorce = req.getParameter("sorce");
        if("patient".equals(sorce)){
            List<Announcement> announcementList = announcementService.getAnnouncementListNotPage();
            PrintWriter writer = resp.getWriter();
            writer.print(announcementList);
            writer.flush();
            writer.close();
        }
        else {
            String page = req.getParameter("page");
            //调用业务层查询方法,需要分页用PageInfo
            PageInfo pageInfo = announcementService.getAnnouncementList(page);
            //跳转jsp页面，显示数据，把需要展示数据设置到request作用域中
            req.setAttribute("pageInfo",pageInfo);
            System.out.println("announcementPageInfo = " + pageInfo);
            //使用转发的跳转方式
            req.getRequestDispatcher("/announcementList.jsp").forward(req,resp);
        }





    }
}
