package com.lyx.controller;

import com.lyx.pojo.Admins;
import com.lyx.pojo.Doctors;
import com.lyx.pojo.Patients;
import com.lyx.service.AdminService;
import com.lyx.service.DoctorService;
import com.lyx.service.PatientService;
import com.lyx.service.impl.AdminServiceImpl;
import com.lyx.service.impl.DoctorServiceImpl;
import com.lyx.service.impl.PatientServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/user/login")
public class LoginServlet extends HttpServlet {
    private AdminService adminService = new AdminServiceImpl();
    private DoctorService doctorService = new DoctorServiceImpl();
    private PatientService patientService = new PatientServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String password = req.getParameter("password");
        String rid = req.getParameter("rid");
        if("1".equals(rid)){
            Admins admins = adminService.login(name,password);
            if(admins!=null){
                req.getSession().setAttribute("admins",admins);
                resp.sendRedirect(req.getContextPath() + "/adminIndex.jsp");
            }else{
                resp.sendRedirect(req.getContextPath() + "/login.jsp?flag=f");
            }
        }else if("2".equals(rid)){
            Doctors doctors = doctorService.login(name,password);
            if(doctors!=null){
                req.getSession().setAttribute("doctors",doctors);
                resp.sendRedirect(req.getContextPath() + "/doctorIndex.jsp");
            }else {
                resp.sendRedirect(req.getContextPath() + "/login.jsp?flag=f");
            }
        }else if("3".equals(rid)){
            Patients patients = patientService.login(name,password);
            if(patients!=null){
                req.getSession().setAttribute("patients",patients);
                resp.sendRedirect(req.getContextPath() + "/Front/patientIndex.jsp");
            }else {
                resp.sendRedirect(req.getContextPath() + "/Front/patientLogin.jsp?flag=f");
            }
        }
    }
}
