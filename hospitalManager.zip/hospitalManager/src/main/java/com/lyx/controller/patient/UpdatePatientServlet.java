package com.lyx.controller.patient;

import com.lyx.pojo.Doctors;
import com.lyx.pojo.Patients;
import com.lyx.service.PatientService;
import com.lyx.service.impl.PatientServiceImpl;
import com.lyx.util.FileUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;

@WebServlet("/patient/updatePatient")
@MultipartConfig
public class UpdatePatientServlet extends HttpServlet {
    private PatientService patientService = new PatientServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idnum = req.getParameter("idnum");
        String name = req.getParameter("name");
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");
        String avatar = req.getParameter("avatar");
        Patients patients = new Patients(idnum,name,phone,email);
        patients.setAvatar(avatar);
        Part part = req.getPart("myfile");
        if (part != null && part.getSize() > 0) {
            String myfile = FileUtil.transferTo(req, "myfile");
            patients.setAvatar(myfile);
        }
        boolean flag = patientService.updatePatientByIdNum(patients);
        if(flag){
            resp.sendRedirect(req.getContextPath()+"/patient/getPatientByIdNum?idnum="+idnum);
        }
    }
}
