package com.lyx.controller.patient;

import com.lyx.pojo.Patients;
import com.lyx.service.PatientService;
import com.lyx.service.impl.PatientServiceImpl;
import com.lyx.util.FileUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;

@WebServlet("/patient/patientCharge")
@MultipartConfig
public class PatientChargeServlet extends HttpServlet {
    private PatientService patientService = new PatientServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pay = req.getParameter("price");
        String balance = req.getParameter("balance");
        Double sum = Double.valueOf(balance)+Double.valueOf(pay);
        String pid = req.getParameter("pid");
        String idnum = req.getParameter("idnum");
        boolean flag = patientService.updatePatientBalanceById(pid,String.valueOf(sum));
        if(flag){
            resp.sendRedirect(req.getContextPath()+"/patient/getPatientByIdNum?idnum="+idnum);
        }
    }
}
