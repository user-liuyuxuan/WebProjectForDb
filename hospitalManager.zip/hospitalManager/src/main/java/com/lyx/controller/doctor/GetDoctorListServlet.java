package com.lyx.controller.doctor;

import com.github.pagehelper.PageInfo;
import com.lyx.pojo.DoctorQuery;
import com.lyx.pojo.Doctors;
import com.lyx.service.DoctorService;
import com.lyx.service.impl.DoctorServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


//用于多条件获取医生信息
@WebServlet("/doctor/getDoctorList")
public class GetDoctorListServlet extends HttpServlet {
    private DoctorService doctorsService = new DoctorServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求中的参数
        String departId = req.getParameter("did");
        String ptId = req.getParameter("pid");
        String doctorName = req.getParameter("dname");
        String jobNum = req.getParameter("jobnum");
        String page = req.getParameter("page");
        String sorce = req.getParameter("sorce");
        //创建对象封装查询参数
        DoctorQuery doctorQuery = new DoctorQuery(departId, ptId, jobNum,doctorName , page);
        Integer num = 0;
        //使用转发的跳转方式
        if("patient".equals(sorce))
        {
            num = 8;
            //调用业务层查询方法,需要分页用PageInfo
            PageInfo pageInfo = doctorsService.getDoctorListPage(doctorQuery,num);
            //跳转jsp页面，显示数据，把需要展示数据设置到request作用域中
            req.setAttribute("pageInfo",pageInfo);
            req.setAttribute("doctorQuery",doctorQuery);
            req.getRequestDispatcher("/Front/doctorListSorceFromPatient.jsp").forward(req,resp);
        }
        else{
            num = 5;
            //调用业务层查询方法,需要分页用PageInfo
            PageInfo pageInfo = doctorsService.getDoctorListPage(doctorQuery,num);
            //跳转jsp页面，显示数据，把需要展示数据设置到request作用域中
            req.setAttribute("pageInfo",pageInfo);
            req.setAttribute("doctorQuery",doctorQuery);
            req.getRequestDispatcher("/doctorList.jsp").forward(req,resp);
        }





    }
}
