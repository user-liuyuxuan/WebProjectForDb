package com.lyx.controller.doctor;

import com.lyx.service.DepartService;
import com.lyx.service.DoctorService;
import com.lyx.service.impl.DepartServiceImpl;
import com.lyx.service.impl.DoctorServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/doctor/deleteById")
public class DeleteByIdDoctorServlet extends HttpServlet {
    private DoctorService doctorService = new DoctorServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        boolean flag = doctorService.deleteById(id);
        if (flag) {
            resp.sendRedirect(req.getContextPath()+"/doctor/getDoctorList");
        }
    }
}
