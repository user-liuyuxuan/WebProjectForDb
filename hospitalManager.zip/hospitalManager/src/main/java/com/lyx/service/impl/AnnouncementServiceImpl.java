package com.lyx.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lyx.mapper.AnnouncementMapper;
import com.lyx.pojo.Announcement;
import com.lyx.service.AnnouncementService;
import com.lyx.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;
import java.util.List;

public class AnnouncementServiceImpl implements AnnouncementService {
    @Override
    public PageInfo getAnnouncementList(String page) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            AnnouncementMapper announcementMapper = sqlSession.getMapper(AnnouncementMapper.class);
            //分页查询
            if(page != null && !"".equals(page)){
                PageHelper.startPage(Integer.valueOf(page),5);
            }
            else PageHelper.startPage(1,5);
            //紧跟开始分页的第一个查询会默认自动分页
            List<Announcement> announcementList = announcementMapper.getAnnouncementList();
            //将list转化成PageInfo
            PageInfo announcementPageInfo = new PageInfo(announcementList);
            return announcementPageInfo;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public Announcement getToUpdateAnnouncementData(String anId) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            AnnouncementMapper announcementMapper = sqlSession.getMapper(AnnouncementMapper.class);
            Announcement announcement = null;
            if (!anId.equals("")) {
                announcement = announcementMapper.getToUpdateAnnouncementData(Integer.valueOf(anId));
            }else
            {
                announcement = announcementMapper.getToUpdateAnnouncementData(-1);
            }
            return announcement;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean updateAnnouncementData(Announcement announcement) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            AnnouncementMapper announcementMapper = sqlSession.getMapper(AnnouncementMapper.class);
            announcementMapper.updateAnnouncementData(announcement);
            sqlSession.commit();//提交事务
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();//事务回滚
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean deleteAnnouncementById(String id) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            AnnouncementMapper announcementMapper = sqlSession.getMapper(AnnouncementMapper.class);
            announcementMapper.deleteAnnouncementById(id);
            sqlSession.commit();//提交事务
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();//事务回滚
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean addAnnouncement(String announcementTitle, String announcementContent, String adminName) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            AnnouncementMapper announcementMapper = sqlSession.getMapper(AnnouncementMapper.class);
            announcementMapper.addDoctorAnnouncement(announcementTitle,announcementContent,adminName);
            sqlSession.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;

    }

    @Override
    public List<Announcement> getAnnouncementListNotPage() {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            AnnouncementMapper announcementMapper = sqlSession.getMapper(AnnouncementMapper.class);
            List<Announcement> announcementList = announcementMapper.getAnnouncementList();
            return announcementList;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }
}
