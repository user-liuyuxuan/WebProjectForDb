package com.lyx.service;

import com.lyx.pojo.DoctorSchedule;

import java.util.List;

public interface ScheduleService {
    List<DoctorSchedule> getDoctorScheduleList(String did);

    boolean updateDoctorScheduleById(String sid);

    DoctorSchedule getDoctorScheduleById(String sid);

    boolean updateDoctorScheduleByDoctorIdAndDateAndShiftTime(String date, String time, String did);
}
