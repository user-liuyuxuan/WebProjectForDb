package com.lyx.service;

import com.lyx.pojo.Appointments;
import com.lyx.pojo.DoctorSchedule;

import java.util.List;

public interface AppointmentService {
    boolean addAppointment(DoctorSchedule doctorSchedule, String pid);

    List<Appointments> getAppointmentListByPid(String pid);

    boolean deleteAppointmentByAid(String aid);
}
