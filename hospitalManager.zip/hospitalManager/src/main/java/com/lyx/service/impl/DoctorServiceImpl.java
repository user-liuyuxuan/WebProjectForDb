package com.lyx.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lyx.mapper.DoctorMapper;
import com.lyx.pojo.DoctorQuery;
import com.lyx.pojo.DoctorSchedule;
import com.lyx.pojo.Doctors;
import com.lyx.service.DoctorService;
import com.lyx.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;
import java.util.List;

public class DoctorServiceImpl implements DoctorService {
    @Override
    public Doctors login(String name, String password) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DoctorMapper doctorMapper = sqlSession.getMapper(DoctorMapper.class);
            return doctorMapper.login(name,password);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean addDoctor(String cid, String num) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            DoctorMapper doctorMapper = sqlSession.getMapper(DoctorMapper.class);
            String jobnumber = doctorMapper.getJobNumberMax();
            int jobNum = Integer.parseInt(jobnumber);
            for(int i = 0; i < Integer.parseInt(num); i++) {
                doctorMapper.addDoctor(cid,++jobNum);
            }
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public PageInfo getDoctorListPage(DoctorQuery doctorQuery, Integer num) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DoctorMapper doctorMapper = sqlSession.getMapper(DoctorMapper.class);
            String page = doctorQuery.getPage();
            if(page!=null&&!"".equals(page)){
                PageHelper.startPage(Integer.valueOf(page), num);
            }else {
                PageHelper.startPage(1, num);
            }
            List<Doctors> dlist = doctorMapper.getDoctorList(doctorQuery);
            PageInfo pageInfo = new PageInfo(dlist);
            System.out.println("pageInfo = " + pageInfo);
            return pageInfo;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean deleteById(String id) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            DoctorMapper doctorMapper = sqlSession.getMapper(DoctorMapper.class);
            doctorMapper.deleteById(id);
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean updateDoctorByJobNumber(Doctors doctors) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            DoctorMapper doctorMapper = sqlSession.getMapper(DoctorMapper.class);
            doctorMapper.updateDoctorByJobNumber(doctors);
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public Doctors getDoctorById(String did) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DoctorMapper doctorMapper = sqlSession.getMapper(DoctorMapper.class);
            Doctors doctors = doctorMapper.getDoctorById(did);
            return doctors;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public PageInfo getDoctorAllSchedule(String page) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DoctorMapper doctorsMapper = sqlSession.getMapper(DoctorMapper.class);
            //分页查询
            if(page != null && !"".equals(page)){
                PageHelper.startPage(Integer.valueOf(page),5);
            }
            else PageHelper.startPage(1,5);
            //紧跟开始分页的第一个查询会默认自动分页
            List<DoctorSchedule> doctorsList = doctorsMapper.getDoctorAllSchedule();
            //将list转化成PageInfo
            PageInfo doctorsPageInfo = new PageInfo(doctorsList);
            System.out.println("pageInfoAllSchedule = " + doctorsPageInfo);
            return doctorsPageInfo;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public PageInfo getDoctorSchedule(DoctorSchedule doctorSchedule, String page) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DoctorMapper doctorsMapper = sqlSession.getMapper(DoctorMapper.class);
            //分页查询
            if(page != null && !"".equals(page)){
                PageHelper.startPage(Integer.valueOf(page),5);
            }
            else PageHelper.startPage(1,5);
            //紧跟开始分页的第一个查询会默认自动分页
            List<DoctorSchedule> doctorsSchedule = doctorsMapper.getDoctorScheduleList(doctorSchedule);
            //将list转化成PageInfo
            PageInfo doctorsPageInfo = new PageInfo(doctorsSchedule);
            return doctorsPageInfo;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public List<Doctors> getDoctorByDepartId(String departId) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DoctorMapper doctorsMapper = sqlSession.getMapper(DoctorMapper.class);
            //紧跟开始分页的第一个查询会默认自动分页
            Integer id = Integer.valueOf(departId);
            List<Doctors> doctorsList = doctorsMapper.getDoctorByDepartId(id);
            return doctorsList;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean addSchedule(String doctorId, String currentDate, String departId, String sTime, String scheduleNum) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            DoctorMapper doctorsMapper = sqlSession.getMapper(DoctorMapper.class);
            doctorsMapper.addSchedule(Integer.valueOf(doctorId),currentDate,Integer.valueOf(departId),sTime,Integer.valueOf(scheduleNum));
            sqlSession.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean determineScheduleExists(DoctorSchedule temp) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DoctorMapper doctorsMapper = sqlSession.getMapper(DoctorMapper.class);

            int count  = doctorsMapper.determineScheduleExists(temp);
            System.out.println("count = " + count);
            return count<=0;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean updateDoctorSchedule(Integer valueOf, Integer valueOf1, String shiftTime, String date) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            DoctorMapper doctorMapper = sqlSession.getMapper(DoctorMapper.class);
            doctorMapper.updateDoctorByDid(valueOf,valueOf1,shiftTime,date);
            sqlSession.commit();//提交事务
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();//事务回滚
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }
}
