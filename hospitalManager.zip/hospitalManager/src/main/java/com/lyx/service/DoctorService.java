package com.lyx.service;

import com.github.pagehelper.PageInfo;
import com.lyx.pojo.DoctorQuery;
import com.lyx.pojo.DoctorSchedule;
import com.lyx.pojo.Doctors;

import java.util.List;

public interface DoctorService {
    public Doctors login(String name, String password);

    boolean addDoctor(String cid, String num);

    PageInfo getDoctorListPage(DoctorQuery doctorQuery, Integer num);

    boolean deleteById(String id);

    boolean updateDoctorByJobNumber(Doctors doctors);

    Doctors getDoctorById(String did);

    PageInfo getDoctorAllSchedule(String page);

    PageInfo getDoctorSchedule(DoctorSchedule doctorSchedule, String page);

    List<Doctors> getDoctorByDepartId(String departId);

    boolean addSchedule(String doctorId, String currentDate, String departId, String sTime, String scheduleNum);

    boolean determineScheduleExists(DoctorSchedule temp);

    boolean updateDoctorSchedule(Integer valueOf, Integer valueOf1, String shiftTime, String date);
}
