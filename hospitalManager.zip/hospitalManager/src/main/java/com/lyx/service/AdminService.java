package com.lyx.service;

import com.lyx.pojo.Admins;

import java.sql.SQLException;

public interface AdminService {
    public Admins login(String name, String password);
}
