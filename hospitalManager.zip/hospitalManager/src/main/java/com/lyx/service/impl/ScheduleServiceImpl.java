package com.lyx.service.impl;

import com.lyx.mapper.DepartMapper;
import com.lyx.mapper.DoctorMapper;
import com.lyx.mapper.ScheduleMapper;
import com.lyx.pojo.Departments;
import com.lyx.pojo.DoctorSchedule;
import com.lyx.service.ScheduleService;
import com.lyx.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;
import java.util.List;

public class ScheduleServiceImpl implements ScheduleService {
    @Override
    public List<DoctorSchedule> getDoctorScheduleList(String did) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            ScheduleMapper scheduleMapper = sqlSession.getMapper(ScheduleMapper.class);
            List<DoctorSchedule> doctorScheduleList = scheduleMapper.getDoctorScheduleList(did);
            return doctorScheduleList;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean updateDoctorScheduleById(String sid) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            ScheduleMapper scheduleMapper = sqlSession.getMapper(ScheduleMapper.class);
            scheduleMapper.updateDoctorScheduleById(sid);
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public DoctorSchedule getDoctorScheduleById(String sid) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            ScheduleMapper scheduleMapper = sqlSession.getMapper(ScheduleMapper.class);
            DoctorSchedule doctorSchedule = scheduleMapper.getDoctorScheduleById(sid);
            return doctorSchedule;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean updateDoctorScheduleByDoctorIdAndDateAndShiftTime(String date, String time, String did) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            ScheduleMapper scheduleMapper = sqlSession.getMapper(ScheduleMapper.class);
            scheduleMapper.updateDoctorScheduleByDoctorIdAndDateAndShiftTime(date,time,did);
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }
}
