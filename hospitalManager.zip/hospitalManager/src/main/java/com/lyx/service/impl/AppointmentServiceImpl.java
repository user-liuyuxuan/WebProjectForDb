package com.lyx.service.impl;

import com.lyx.mapper.AdminMapper;
import com.lyx.mapper.AppointmentMapper;
import com.lyx.mapper.ScheduleMapper;
import com.lyx.pojo.Appointments;
import com.lyx.pojo.DoctorSchedule;
import com.lyx.service.AppointmentService;
import com.lyx.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;
import java.util.List;

public class AppointmentServiceImpl implements AppointmentService {
    @Override
    public boolean addAppointment(DoctorSchedule doctorSchedule, String pid) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            AppointmentMapper appointmentMapper = sqlSession.getMapper(AppointmentMapper.class);
            appointmentMapper.addAppointment(doctorSchedule,pid);
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public List<Appointments> getAppointmentListByPid(String pid) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            AppointmentMapper appointmentMapper = sqlSession.getMapper(AppointmentMapper.class);
            List<Appointments> appointmentsList = appointmentMapper.getAppointmentListByPid(pid);
            return appointmentsList;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean deleteAppointmentByAid(String aid) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            AppointmentMapper appointmentMapper = sqlSession.getMapper(AppointmentMapper.class);
            appointmentMapper.deleteAppointmentListByPid(aid);
            sqlSession.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }
}
