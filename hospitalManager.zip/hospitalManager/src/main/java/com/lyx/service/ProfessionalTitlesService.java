package com.lyx.service;

import com.github.pagehelper.PageInfo;
import com.lyx.pojo.ProfessionalTitles;

import java.util.List;

public interface ProfessionalTitlesService {
    List<ProfessionalTitles> getProfessionalTitlesList();

    boolean deleteDoctorProfessonalTitlesById(int id);
    PageInfo getDoctorProfessionalTitlesListPage(String page);

    boolean addDoctorProfessionalTitles(String doctorProfessionalTitles, String doctorProfessionalTitlesDescript);


}
