package com.lyx.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lyx.mapper.DepartMapper;
import com.lyx.pojo.Departments;
import com.lyx.service.DepartService;
import com.lyx.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class DepartServiceImpl implements DepartService {

    @Override
    public PageInfo getDepartListPage(String page, int pid) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DepartMapper departMapper = sqlSession.getMapper(DepartMapper.class);
            if(page!=null&&!"".equals(page)){
                PageHelper.startPage(Integer.valueOf(page), 5);
            }else {
                PageHelper.startPage(1, 5);
            }
            List<Departments> departList = departMapper.getDepartList(pid);
            for(Departments depart:departList){
                Integer departmentId = depart.getDepartmentId();
                int count = departMapper.getChildCount(departmentId);
                if(count>0){
                    depart.setHaschild(true);
                }else{
                    depart.setHaschild(false);
                }
            }
            PageInfo<Departments> pageInfo = new PageInfo<>(departList);
            System.out.println("pageInfo = " + pageInfo);
            return pageInfo;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public List<Departments> getDepartListAll(String pid) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DepartMapper departMapper = sqlSession.getMapper(DepartMapper.class);
            List<Departments> departList = departMapper.getDepartList(Integer.valueOf(pid));
            return departList;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean addDepartment(Departments departments) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            DepartMapper departMapper = sqlSession.getMapper(DepartMapper.class);
            departMapper.addDepartment(departments);
            sqlSession.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public Departments getDepartById(String did) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DepartMapper departMapper = sqlSession.getMapper(DepartMapper.class);
            Departments departments = departMapper.getDepartById(did);
            return departments;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean updateDepartment(Departments departments) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            DepartMapper departMapper = sqlSession.getMapper(DepartMapper.class);
            departMapper.updateDepartment(departments);
            sqlSession.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean deleteById(String id) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            DepartMapper departMapper = sqlSession.getMapper(DepartMapper.class);
            departMapper.deleteById(id);
            sqlSession.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public List<Departments> getDepartListLevel(Integer level) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            DepartMapper departMapper = sqlSession.getMapper(DepartMapper.class);
            return departMapper.getDepartListLevel(level);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }
}
