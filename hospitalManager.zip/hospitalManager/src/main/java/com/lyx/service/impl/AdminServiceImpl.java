package com.lyx.service.impl;

import com.lyx.mapper.AdminMapper;
import com.lyx.pojo.Admins;
import com.lyx.service.AdminService;
import com.lyx.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;

public class AdminServiceImpl implements AdminService {

    @Override
    public Admins login(String name, String password){
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            AdminMapper adminMapper = sqlSession.getMapper(AdminMapper.class);
            return adminMapper.login(name,password);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }
}
