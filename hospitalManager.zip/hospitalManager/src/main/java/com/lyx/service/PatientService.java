package com.lyx.service;

import com.github.pagehelper.PageInfo;
import com.lyx.pojo.Patients;

public interface PatientService {
    Patients login(String name, String password);

    boolean patientSignin(Patients patients);

    boolean checkIdNum(String idnum);

    boolean updatePatientByIdNum(Patients patients);

    Patients getPatientByIdNum(String idnum);

    boolean updatePatientBalanceById(String pid, String restfee);

    boolean checkPhoneNum(String phone);

    boolean deletePatientsById(Integer valueOf);

    PageInfo getPatientsList(String page);

    PageInfo searchPatientsList(String patientName, String patientIdCardNumber, String page);
}
