package com.lyx.service;

import com.github.pagehelper.PageInfo;
import com.lyx.pojo.Departments;

import java.util.List;

public interface DepartService {
    PageInfo getDepartListPage(String page,int pid);

    List<Departments> getDepartListAll(String pid);

    boolean addDepartment(Departments departments);

    Departments getDepartById(String did);

    boolean updateDepartment(Departments departments);

    boolean deleteById(String id);

    List<Departments> getDepartListLevel(Integer level);
}
