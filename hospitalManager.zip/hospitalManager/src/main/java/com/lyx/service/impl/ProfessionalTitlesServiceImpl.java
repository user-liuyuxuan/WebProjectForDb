package com.lyx.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lyx.mapper.DoctorMapper;
import com.lyx.mapper.ProfessionalTitlesMapper;
import com.lyx.pojo.ProfessionalTitles;
import com.lyx.service.ProfessionalTitlesService;
import com.lyx.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;
import java.util.List;

public class ProfessionalTitlesServiceImpl implements ProfessionalTitlesService {
    @Override
    public List<ProfessionalTitles> getProfessionalTitlesList() {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            ProfessionalTitlesMapper professionalTitlesMapper = sqlSession.getMapper(ProfessionalTitlesMapper.class);
            return professionalTitlesMapper.getProfessionalTitlesList();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean deleteDoctorProfessonalTitlesById(int id) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            ProfessionalTitlesMapper departmentsMapper = sqlSession.getMapper(ProfessionalTitlesMapper.class);
            departmentsMapper.deleteById(id);
            sqlSession.commit();//提交事务
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();//事务回滚
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public PageInfo getDoctorProfessionalTitlesListPage(String page) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            ProfessionalTitlesMapper doctorsMapper = sqlSession.getMapper(ProfessionalTitlesMapper.class);
            //分页查询
            //紧跟开始分页的第一个查询会默认自动分页
            if(page != null && !"".equals(page)){
                PageHelper.startPage(Integer.valueOf(page),5);
            }
            else PageHelper.startPage(1,5);
            List<ProfessionalTitles> scheduleList = doctorsMapper.getDoctorProfessionalTitles();
            //将list转化成PageInfo
            PageInfo scheduleByIdPageInfo = new PageInfo(scheduleList);
            System.out.println("pageInfoScheduleById = " + scheduleByIdPageInfo);
            return scheduleByIdPageInfo;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean addDoctorProfessionalTitles(String doctorProfessionalTitles, String doctorProfessionalTitlesDescript) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            ProfessionalTitlesMapper professionalTitlesMapper = sqlSession.getMapper(ProfessionalTitlesMapper.class);
            professionalTitlesMapper.addDoctorProfessionalTitles(doctorProfessionalTitles,doctorProfessionalTitlesDescript);
            sqlSession.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

}
