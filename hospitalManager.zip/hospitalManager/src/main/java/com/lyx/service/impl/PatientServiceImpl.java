package com.lyx.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lyx.mapper.DoctorMapper;
import com.lyx.mapper.PatientMapper;
import com.lyx.pojo.Patients;
import com.lyx.service.PatientService;
import com.lyx.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;
import java.util.List;

public class PatientServiceImpl implements PatientService {
    @Override
    public Patients login(String name, String password) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            PatientMapper patientMapper = sqlSession.getMapper(PatientMapper.class);
            return patientMapper.login(name,password);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean patientSignin(Patients patients) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            PatientMapper patientMapper = sqlSession.getMapper(PatientMapper.class);
            patientMapper.patientSignin(patients);
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean checkIdNum(String idnum) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            PatientMapper patientMapper = sqlSession.getMapper(PatientMapper.class);
            int count = patientMapper.checkIdNum(idnum);
            return count<=0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean updatePatientByIdNum(Patients patients) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            PatientMapper patientMapper = sqlSession.getMapper(PatientMapper.class);
            patientMapper.updatePatientByIdNum(patients);
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public Patients getPatientByIdNum(String idnum) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            PatientMapper patientMapper = sqlSession.getMapper(PatientMapper.class);
            return patientMapper.getPatientByIdNum(idnum);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

    @Override
    public boolean updatePatientBalanceById(String pid, String restfee) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            PatientMapper patientMapper = sqlSession.getMapper(PatientMapper.class);
            patientMapper.updatePatientBalanceById(pid,restfee);
            sqlSession.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sqlSession.rollback();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean checkPhoneNum(String phone) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            PatientMapper patientMapper = sqlSession.getMapper(PatientMapper.class);
            int count = patientMapper.checkPhoneNum(phone);
            return count<=0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;
    }

    @Override
    public boolean deletePatientsById(Integer valueOf) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        try {
            PatientMapper patientsMapper = sqlSession.getMapper(PatientMapper.class);
            patientsMapper.deletePatientsById(valueOf);
            sqlSession.commit();//提交事务
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            sqlSession.rollback();//事务回滚
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return false;

    }

    @Override
    public PageInfo getPatientsList(String page) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            PatientMapper patientsMapper = sqlSession.getMapper(PatientMapper.class);
            //分页查询
            if(page != null && !"".equals(page)){
                PageHelper.startPage(Integer.valueOf(page),5);
            }
            else PageHelper.startPage(1,5);
            List<Patients> patientsList = patientsMapper.getPtientsList();
            //将list转化成PageInfo
            PageInfo patientsPageInfo = new PageInfo(patientsList);
            System.out.println("patientsPageInfo = " + patientsPageInfo);
            return patientsPageInfo;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;

    }

    @Override
    public PageInfo searchPatientsList(String patientName, String patientIdCardNumber, String page) {
        try {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            PatientMapper patientsMapper = sqlSession.getMapper(PatientMapper.class);
            //分页查询
            if(page != null && !"".equals(page)){
                PageHelper.startPage(Integer.valueOf(page),5);
            }
            else PageHelper.startPage(1,5);
            //紧跟开始分页的第一个查询会默认自动分页
            List<Patients> searchPatients = patientsMapper.searchPatientsList(patientName,patientIdCardNumber);
            //将list转化成PageInfo
            PageInfo patientsPageInfo = new PageInfo(searchPatients);
            return patientsPageInfo;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MybatisUtil.closeSqlSession();
        }
        return null;
    }

}
