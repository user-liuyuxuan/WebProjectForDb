package com.lyx.service;

import com.github.pagehelper.PageInfo;
import com.lyx.pojo.Announcement;

import java.util.List;

public interface AnnouncementService {
    PageInfo getAnnouncementList(String page);

    Announcement getToUpdateAnnouncementData(String anId);

    boolean updateAnnouncementData(Announcement announcement);

    boolean deleteAnnouncementById(String id);

    boolean addAnnouncement(String announcementTitle, String announcementContent, String adminName);

    List<Announcement> getAnnouncementListNotPage();
}
