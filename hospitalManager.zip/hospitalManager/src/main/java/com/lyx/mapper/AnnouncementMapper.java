package com.lyx.mapper;

import com.lyx.pojo.Announcement;
import org.apache.ibatis.annotations.*;

import java.sql.SQLException;
import java.util.List;

public interface AnnouncementMapper {

    @Select("select * from announcement")
    List<Announcement> getAnnouncementList()throws SQLException;
    @Select("select * from announcement where announcement_id=#{id}")
    Announcement getToUpdateAnnouncementData(@Param("id") Integer id)throws SQLException;
    @Update("update announcement set title=#{title},content=#{content} where announcement_id=#{announcementId}")
    void updateAnnouncementData(Announcement announcement)throws SQLException;

    @Delete("delete from announcement where announcement_id=#{id}")
    void deleteAnnouncementById(@Param("id") String id)throws SQLException;


    @Insert("insert into announcement (title, content,creator) value(#{announcementTitle},#{announcementContent},#{adminName})")
    void addDoctorAnnouncement(@Param("announcementTitle")String announcementTitle,@Param("announcementContent") String announcementContent,@Param("adminName")String adminName)throws SQLException;
}
