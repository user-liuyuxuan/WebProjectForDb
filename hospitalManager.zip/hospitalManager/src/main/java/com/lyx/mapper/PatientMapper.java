package com.lyx.mapper;

import com.lyx.pojo.Patients;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.sql.SQLException;
import java.util.List;

public interface PatientMapper {
    @Select("select * from patients where id_card_number=#{idnum} and password=#{pwd}")
    Patients login(@Param("idnum") String name,@Param("pwd") String password) throws SQLException;

    @Insert("insert into patients(id_card_number,password,name,avatar,phone,email) values(#{idCardNumber},#{password},#{name},#{avatar},#{phone},#{email})")
    void patientSignin(Patients patients) throws SQLException;

    @Select("select count(id_card_number) from patients where id_card_number=#{idnum}")
    int checkIdNum(@Param("idnum") String idnum) throws SQLException;

    @Update("update patients set name=#{name},avatar=#{avatar},phone=#{phone},email=#{email} where id_card_number=#{idCardNumber}")
    void updatePatientByIdNum(Patients patients) throws SQLException;

    @Select("select * from patients where id_card_number=#{idnum}")
    Patients getPatientByIdNum(String idnum) throws SQLException;

    @Update("update patients set balance=#{restfee} where patient_id=#{pid}")
    void updatePatientBalanceById(@Param("pid") String pid,@Param("restfee") String restfee) throws SQLException;

    @Select("select count(phone) from patients where phone=#{phone}")
    int checkPhoneNum(String phone) throws SQLException;

    @Update("update patients set state=1 where patients.patient_id=#{id}")
    void deletePatientsById(@Param("id") int id)throws SQLException;

    @Select("select * from patients where state=0")
    List<Patients> getPtientsList() throws SQLException;

    @Select("select * from patients where name=#{patientName} or id_card_number=#{patientIdCardNumber}")
    List<Patients> searchPatientsList(@Param("patientName") String patientName,@Param("patientIdCardNumber") String patientIdCardNumber);
}
