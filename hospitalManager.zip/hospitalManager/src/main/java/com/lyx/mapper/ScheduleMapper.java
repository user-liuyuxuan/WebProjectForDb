package com.lyx.mapper;

import com.lyx.pojo.DoctorSchedule;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.sql.SQLException;
import java.util.List;

public interface ScheduleMapper {


    List<DoctorSchedule> getDoctorScheduleList(@Param("did") String did) throws SQLException;

    @Update("update doctor_schedule set visit_count=visit_count+1 where schedule_id=#{sid}")
    void updateDoctorScheduleById(@Param("sid") String sid) throws SQLException;

    @Select("select * from doctor_schedule where schedule_id=#{sid}")
    DoctorSchedule getDoctorScheduleById(String sid);

    @Update("update doctor_schedule set visit_count=visit_count-1 where shift_time=#{time} and `date`=#{date} and doctor_id=#{did}")
    void updateDoctorScheduleByDoctorIdAndDateAndShiftTime(@Param("date") String date,@Param("time") String time,@Param("did") String did) throws SQLException;
}
