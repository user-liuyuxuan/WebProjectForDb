package com.lyx.mapper;

import com.lyx.pojo.DoctorQuery;
import com.lyx.pojo.DoctorSchedule;
import com.lyx.pojo.Doctors;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.sql.SQLException;
import java.util.List;

public interface DoctorMapper {
    @Select("select * from doctors where job_number=#{job} and password=#{pwd}")
    Doctors login(@Param("job") String name, @Param("pwd") String password) throws SQLException;

    @Select("select max(job_number) from doctors")
    String getJobNumberMax() throws SQLException;

    @Insert("insert into doctors(job_number,password,department_id) values(#{jobNum},'123456',#{did})")
    void addDoctor(@Param("did") String did, @Param("jobNum") int jobNum) throws SQLException;

    List<Doctors> getDoctorList(DoctorQuery doctorQuery) throws SQLException;

    @Update("update doctors set state=0 where doctor_id=#{id}")
    void deleteById(String id) throws SQLException;

    @Update("update doctors set name=#{name},avatar=#{avatar},phone=#{phone},email=#{email},introduction=#{introduction},registration_fee=#{registrationFee},entry_date=#{entryDate},professional_title_id=#{professionalTitleId} where job_number=#{jobNumber}")
    void updateDoctorByJobNumber(Doctors doctors) throws SQLException;

    Doctors getDoctorById(String did) throws SQLException;

    List<DoctorSchedule> getDoctorAllSchedule() throws SQLException;

    List<DoctorSchedule> getDoctorScheduleList(DoctorSchedule doctorSchedule) throws SQLException;


    @Select("select * from doctors where department_id=#{id}")
    List<Doctors> getDoctorByDepartId(Integer id) throws SQLException;


    @Insert("insert into doctor_schedule(doctor_id, date, shift_time, department_id, is_available, sum_count) value(#{doctorId},#{currentDate},#{shifTime},#{departId},1,#{scheduleNum})")
    void addSchedule(@Param("doctorId")Integer doctorId,@Param("currentDate")String currentDate, @Param("departId")Integer departId, @Param("shifTime")String shifTime, @Param("scheduleNum")Integer scheduleNum)throws SQLException;



    @Select("select count(doctor_id) from doctor_schedule where doctor_id=#{doctorId} and shift_time=#{shiftTime} and date=#{date} and department_id=#{departmentId}")
    int determineScheduleExists(DoctorSchedule doctorSchedule)throws SQLException;


    @Update("update doctor_schedule d set sum_count=#{num} where d.date=#{date} and doctor_id=#{did}  and shift_time=#{shiftTime} ")
    void updateDoctorByDid(@Param("did") Integer did,@Param("num") Integer num,@Param("shiftTime") String shiftTime,@Param("date") String date)throws SQLException;


}
