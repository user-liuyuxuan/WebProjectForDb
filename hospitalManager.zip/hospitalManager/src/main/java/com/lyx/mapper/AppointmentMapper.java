package com.lyx.mapper;

import com.lyx.pojo.Appointments;
import com.lyx.pojo.DoctorSchedule;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.sql.SQLException;
import java.util.List;

public interface AppointmentMapper {
    @Insert("insert into appointments(patient_id,doctor_id,appointment_date,appointment_time,status) values (#{pid},#{doctorSchedule.doctorId},#{doctorSchedule.date},#{doctorSchedule.shiftTime},'booked')")
    void addAppointment(@Param("doctorSchedule") DoctorSchedule doctorSchedule, @Param("pid") String pid) throws SQLException;

    List<Appointments> getAppointmentListByPid(String pid);

    @Delete("delete from appointments where appointment_id=#{aid}")
    void deleteAppointmentListByPid(String aid) throws SQLException;
}
