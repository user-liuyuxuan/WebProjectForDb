package com.lyx.mapper;

import com.lyx.pojo.ProfessionalTitles;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.sql.SQLException;
import java.util.List;

public interface ProfessionalTitlesMapper {
    @Select("select * from professional_titles")
    List<ProfessionalTitles> getProfessionalTitlesList() throws SQLException;

    @Select("select * from professional_titles where state=0")
    List<ProfessionalTitles> getDoctorProfessionalTitles()throws SQLException;

    @Update("update professional_titles set state=1 where professional_titles.id=#{id}")
    void deleteById(@Param("id") int id) throws SQLException;


    @Insert("insert into professional_titles (title_name, description) value(#{doctorProfessionalTitles},#{doctorProfessionalTitlesDescript})")
    void addDoctorProfessionalTitles(@Param("doctorProfessionalTitles") String doctorProfessionalTitles,@Param("doctorProfessionalTitlesDescript") String doctorProfessionalTitlesDescript) throws SQLException;


}
