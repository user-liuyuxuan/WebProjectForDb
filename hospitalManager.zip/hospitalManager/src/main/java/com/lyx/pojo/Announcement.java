package com.lyx.pojo;

public class Announcement {
    private Integer announcementId;
    private String title;
    private String content;
    private String creationTime;
    private String creator;

    public Announcement(Integer announcementId, String title, String content, String creationTime, String creator) {
        this.announcementId = announcementId;
        this.title = title;
        this.content = content;
        this.creationTime = creationTime;
        this.creator = creator;
    }

    public Announcement() {
    }

    public Integer getAnnouncementId() {
        return announcementId;
    }

    public void setAnnouncementId(Integer announcementId) {
        this.announcementId = announcementId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(String creationTime) {
        this.creationTime = creationTime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
}
