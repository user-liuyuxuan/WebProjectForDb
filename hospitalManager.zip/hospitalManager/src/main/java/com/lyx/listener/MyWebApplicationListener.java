package com.lyx.listener;

import com.lyx.pojo.Departments;
import com.lyx.pojo.ProfessionalTitles;
import com.lyx.service.DepartService;
import com.lyx.service.ProfessionalTitlesService;
import com.lyx.service.impl.DepartServiceImpl;
import com.lyx.service.impl.ProfessionalTitlesServiceImpl;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.util.List;


@WebListener
public class MyWebApplicationListener implements ServletContextListener {
    private DepartService departService = new DepartServiceImpl();
    private ProfessionalTitlesService professionalTitlesService = new ProfessionalTitlesServiceImpl();
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("监听" + sce);
        List<ProfessionalTitles> professionalTitlesList = professionalTitlesService.getProfessionalTitlesList();
        List<Departments> dListLevelf = departService.getDepartListLevel(1);
        List<Departments> dListLevelt = departService.getDepartListLevel(2);
        ServletContext application = sce.getServletContext();
        application.setAttribute("ptlist", professionalTitlesList);
        application.setAttribute("dListLevelf", dListLevelf);
        application.setAttribute("dListLevelt", dListLevelt);
    }
}
